import { Component, OnInit , Input , Output , EventEmitter} from '@angular/core';
import { EmployeeServiceService } from '../employee-service.service';

@Component({
  selector: 'app-test-component',
  templateUrl: './test-component.component.html',
  styleUrls: ['./test-component.component.scss']
})
export class TestComponentComponent implements OnInit {
  /**
   * for getting and assign the valus from service
   */
  public employeeDetails:Array<object>;

  /**
   * for getting the input element
   */
  @Input() public parentMessage:boolean ;
  /**`
   * for output to the parent component 
   */
  @Output() public  testOutput = new EventEmitter();

  /**
   * for creating service object
   * @param _empService 
   */

  constructor(private _empService: EmployeeServiceService) { }

  ngOnInit() {
    this.employeeDetails = this._empService.getDetails();    
  }

  /**
   * edit
   */
  public addNew() {
    this.testOutput.emit(true);
  }
}
