export  interface sampleInterface
{    
    name:String,
    age:Number,
    work:String
}