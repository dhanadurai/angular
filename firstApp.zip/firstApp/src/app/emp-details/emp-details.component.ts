import { Component, OnInit , Output , EventEmitter } from '@angular/core';
import { EmployeeServiceService } from '../employee-service.service';

@Component({
  selector: 'app-emp-details',
  templateUrl: './emp-details.component.html',
  styleUrls: ['./emp-details.component.scss']
})
export class EmpDetailsComponent implements OnInit {

  /**
   * for error messge
   */
  public error:boolean =false;  
  public aError:boolean = false;
  public ageError:string = "please give the age above 20";
  
  
  /**
   * for empDetails   
   */
  public employeeDetails:Array<object>;

  /**
   * for the ename    
   */
  public ename:string ="";

  /**
   * for the age    
   */
  public age:number;
  /**
   * for the ename    
   */
  public newValues:object;

  /**
   * for the output
   */
  @Output() public empDetailsOutput = new EventEmitter();
  
  /**
   * for the work    
   */
  public work:string ="";

  constructor(private _employeeService: EmployeeServiceService) { }

  ngOnInit() {
    this.employeeDetails = this._employeeService.getDetails();    
  }

  /**
   * save
   */
  public save() {
    if(this.ename=='' || this.work=='')
    {
      this.error=true;
      this.aError=false;
    }
    else if(this.age < 18)
    {
      this.error=false;
      this.aError=true;
    }
    else
    {
      this.newValues = {"name":this.ename,"age":this.age,"work":this.work};            
      this._employeeService.setDetails(this.newValues);            
      this.empDetailsOutput.emit(true);
    }
  }
}
