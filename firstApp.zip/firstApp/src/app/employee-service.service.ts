import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class EmployeeServiceService {

  /***
   * for give the employee details to the service
   */
  public empDetails:Array<object> ;

  /**
   * for get the details from the service
   */
  // public getEmpDetails:any;

  constructor() {
    this.empDetails = [
      {"name":"Vimaladarsan","age":25,"work":"Manager"},
      {"name":"Ranjani","age":22,"work":"software Trainee"},
      {"name":"Dhananchezhiyan D","age":21,"work":"software Trainee"}
  ];
   }

  /**
   * getDetails
   */
  public getDetails() {
   return  this.empDetails;
  }

  /**
   * setDetails
   */
  public setDetails(newValues):void {
    this.empDetails.push(newValues) ;    
  }
}
