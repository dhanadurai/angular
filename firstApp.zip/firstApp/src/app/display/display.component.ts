import { Component, OnInit } from '@angular/core';
import { EmployeeServiceService } from '../employee-service.service';

@Component({
  selector: 'app-display',
  templateUrl: './display.component.html',
  styleUrls: ['./display.component.scss']
})
export class DisplayComponent implements OnInit {
/***
 * for store the service values
 */
public employeeList:Array<object>;
  constructor(private _empDetailsService : EmployeeServiceService) { }

  ngOnInit() 
  {
    this.employeeList = this._empDetailsService.empDetails;
  }

}
