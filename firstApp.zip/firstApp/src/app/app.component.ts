import { Component  } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'firstApp';
  /**
   * for get the output from child test component
   */
  public testMessage:boolean = false;
  /**
   * for user name as string 
   */
  public username:string = "";
  
 
  /**
   * for password as string 
   */
  public password = "";

  /**
   * error messages
   */
  public unameError = "please enter the username";
  public pwdError = "please enter the password";

  /**
   * component show flag
   */
  public componentFlag = false;

  /**
   * employee details flag
   */
  public empMessage:boolean = false ;

   /**
   * for send the message from parent
   */
  public parentMessage: Boolean;
  /**
   * error flags
   */
  public uError = false;
  public pError = false;
  public aError = false;

 
  /**
   * logIn function 
   */
  public login()
  {
    if(this.username=="" && this.password=="")
    {
      this.aError  = true;      
      this.uError = false;
      this. pError =false;
    }
    else if (this.username=="")
    {
      this.aError = false;
      this.uError = true;
      this. pError =false;
    }
    else if (this.password=="")
    {
      this.aError = false;
      this.uError = false;
      this. pError =true;
    }
    else
    {
      this.aError = false;
      this.uError = false;
      this. pError =false;
      this.componentFlag=true;    
    }
  }
}
