import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';
import { EmployeeService } from '../employee.service';
import { SampleInterface } from '../sample-interface';

@Component({
  selector: 'app-display-content',
  templateUrl: './display-content.component.html',
  styleUrls: ['./display-content.component.scss']
})
export class DisplayContentComponent implements OnInit {

  public detailsId:number;
  public details:any;
  // public inputDetails:any;
  public serviceValue: SampleInterface[];
  public errorMsg: any;
  constructor(private activeRoute: ActivatedRoute , private route: Router , private empService : EmployeeService) { }

  ngOnInit(): void {
    this.activeRoute.paramMap.subscribe((params:ParamMap) => {
      let getDetails ;
      getDetails = parseInt(params.get('value'));
      this.detailsId = getDetails;
    })
    this.empService.getEmployeeDetails().subscribe(data => this.serviceLog(data) , error => this.errorMsg = error)
  }
  
  /**
   * serviceLog
   */
  public serviceLog(input) {
    this.serviceValue = input;    
    // console.log(this.serviceValue)
    this.checkValue(input);
  }
  
  /**
   * checkValue
   */
  public checkValue(input) {
    this.details = input[this.detailsId-1]
    
  }


  /**
   * backToDisplay()
   */
  public backToDisplay(){    
    this.route.navigate(['../../'],{relativeTo:this.activeRoute});
  }

}
