export interface SampleInterface {
    
        id:number,
        name:string,
        designation:string

    
}
