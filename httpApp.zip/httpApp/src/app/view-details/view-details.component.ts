import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';


@Component({
  selector: 'app-view-details',
  templateUrl: './view-details.component.html',
  styleUrls: ['./view-details.component.scss']
})
export class ViewDetailsComponent implements OnInit {

  public employeeDetails = [];
  public empName =[];
  public empId =[];
  public empWork =[];
  public errorMsg;
  constructor(private _empService : EmployeeService) { }

  ngOnInit() {
    this._empService.getEmployeeDetails().subscribe(data => this.validate(data),
                                                    error => this.errorMsg = error);
  }

  private validate(info)
  {
    this.employeeDetails=info;
    info.forEach(details => {
      this.empName = details.name;
    });   
  }

}
