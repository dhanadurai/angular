import { NgModule } from '@angular/core';
import { Routes, RouterModule, ChildrenOutletContexts } from '@angular/router';
import { AddDetailsComponent } from './add-details/add-details.component';
import { DisplayComponent } from './display/display.component';
import { ViewDetailsComponent } from './view-details/view-details.component';
import { UndefinedPageComponent } from './undefined-page/undefined-page.component';
import { DisplayOverviewComponent } from './display-overview/display-overview.component';
import { DisplayContentComponent } from './display-content/display-content.component';


const routes: Routes = [
  {path:"" , redirectTo:"" , pathMatch:"full"},
  { path : "add-details" , component:AddDetailsComponent },
  { path : "add-details/:details" , component:DisplayComponent ,
    children:[
      { path : "display-overview" , component : DisplayOverviewComponent},
      { path : "display-content/:value" , component : DisplayContentComponent}
    ]
  },
  {path:"viewDetails" , component:ViewDetailsComponent},
  {path:"**" , component : UndefinedPageComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const routeComponents = [AddDetailsComponent, 
                                DisplayComponent , 
                                DisplayOverviewComponent,
                                DisplayContentComponent,
                                ViewDetailsComponent ,
                                UndefinedPageComponent];