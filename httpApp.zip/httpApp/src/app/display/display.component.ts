import { Component, OnInit } from '@angular/core';
import { ActivatedRoute , Router , ParamMap } from '@angular/router';
import { EmployeeService } from '../employee.service';

interface NewType {
  "id": number;
  "name": string;
  "designation": string;
}

@Component({
  selector: 'app-display',
  templateUrl: './display.component.html',
  styleUrls: ['./display.component.scss']
})
export class DisplayComponent implements OnInit {

  public getId: number;
  public getName: string;
  public getwork: string;
  public empDetails: NewType;
  public isDisabled =false;
  public errorMsg: any;

  constructor(private empService: EmployeeService,private route: ActivatedRoute,private router : Router) { }

  ngOnInit() {
    this.route.paramMap.subscribe((params : ParamMap) => {
      let detail:any;
      // detail = JSON.parse(params.get('details'));
      // console.log(detail)
      detail = parseInt(params.get('details'));
      this.getId = detail;      
      // this.getId = detail.id;      
      // this.getName = detail.name;      
      // this.getwork = detail.designation;      
    });    
    this.empService.getEmployeeDetails().subscribe(data => this.change(data), 
                                                   error => this.errorCheck(error));                                                       
  }

 
  /**
   * change
   */
  public change(input) {
    if(input!='')
    {
      this.empDetails = input[this.getId-1];      
    }
  }
  
  public errorCheck(error)
  {
    this.errorMsg = error;
  }
  /**
   * prev
   */
  public prev() {
    let prevId = this.getId = this.getId - 1;
    this.router.navigate(['../',prevId],{relativeTo:this.route});
  }
  
  /**
   * next
   */
  public next() {
    let nextId = this.getId =this.getId+ 1;
    this.router.navigate(['../',nextId],{relativeTo:this.route});
  }

  /**
   * onClick
   */
  public onClick() {
    this.router.navigate(['../',{id : this.getId}],{relativeTo:this.route})
  }

  public showContent()
  { 
    this.isDisabled = false;
    let details = JSON.stringify(this.empDetails);
    this.router.navigate(['display-content',this.getId],{relativeTo:this.route});
  }

  public showOverview()
  {
    this.router.navigate(['display-overview'],{relativeTo:this.route});
  }
}
