import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-display-overview',
  templateUrl: './display-overview.component.html',
  styleUrls: ['./display-overview.component.scss']
})
export class DisplayOverviewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
