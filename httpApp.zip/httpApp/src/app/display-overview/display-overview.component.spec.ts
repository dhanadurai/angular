import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DisplayOverviewComponent } from './display-overview.component';

describe('DisplayOverviewComponent', () => {
  let component: DisplayOverviewComponent;
  let fixture: ComponentFixture<DisplayOverviewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DisplayOverviewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DisplayOverviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
