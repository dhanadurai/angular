import { Injectable } from '@angular/core';
import { HttpErrorResponse, HttpClient } from '@angular/common/http';

import { Observable, throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';
import { SampleInterface } from './sample-interface';
@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  private url = "/assets/emplyoee.json";

  public isHidden = true;

  constructor(private http: HttpClient) { }

  public getEmployeeDetails(): Observable<SampleInterface[]>
  {
      return this.http.get<SampleInterface[]>(this.url).pipe(
        retry(1),
        catchError(this.errorMessage)
      );
  }

  public errorMessage(error : HttpErrorResponse)
  {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
        // client-side error
        errorMessage = `Error: ${error.error.message}`;
    } else {
        // server-side error
        errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    return throwError(errorMessage);
  }
}
