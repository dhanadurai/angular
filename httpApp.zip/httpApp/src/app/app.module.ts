import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from "@angular/forms";
import { HttpClientModule } from '@angular/common/http'

import { AppRoutingModule , routeComponents } from './app-routing.module';
import { AppComponent } from './app.component';
import { UndefinedPageComponent } from './undefined-page/undefined-page.component';
import { DisplayOverviewComponent } from './display-overview/display-overview.component';
import { DisplayContentComponent } from './display-content/display-content.component';
// import { ViewDetailsComponent } from './view-details/view-details.component';
// import { AddDetailsComponent } from './add-details/add-details.component';
// import { DisplayComponent } from './display/display.component';

@NgModule({
  declarations: [
    AppComponent,
    routeComponents,
    UndefinedPageComponent,
    DisplayOverviewComponent,
    DisplayContentComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
