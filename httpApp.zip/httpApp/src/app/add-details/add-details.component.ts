import { Component, OnInit} from '@angular/core';
import { EmployeeService } from '../employee.service';
import { Router , ActivatedRoute , ParamMap} from '@angular/router';


@Component({
  selector: 'app-add-details',
  templateUrl: './add-details.component.html',
  styleUrls: ['./add-details.component.scss']
})
export class AddDetailsComponent implements OnInit {

  public empDetails;
  selectedId: any;
  errorMsg: any;
  
  constructor(private _empService: EmployeeService, private route: Router ,private activeRoute: ActivatedRoute) { }

  ngOnInit() {
    this.activeRoute.paramMap.subscribe((params : ParamMap) => {
      let detail:any; 
      detail = parseInt(params.get('id'));  
      this.selectedId = detail;          
    });    
    this._empService.getEmployeeDetails().subscribe(data => this.empDetails = data,
                                                            error => this.errorMsg = error);
  }

  /**
   * onClick
   */
  public onClick(details) {
      //  console.log(details)
      let objDetails = JSON.stringify(details);
      //  this.route.navigate(['/addDetails',details.id])
      this.route.navigate([details.id],{relativeTo : this.activeRoute});
  }

  public isSelected(details)
  {
    return details.id === this.selectedId;
  }

}
